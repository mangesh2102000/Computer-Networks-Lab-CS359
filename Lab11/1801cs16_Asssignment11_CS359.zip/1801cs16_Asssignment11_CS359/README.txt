/* Name: Chandrawanshi Mangesh Shivaji
Roll No: 1801cs16
Date: 22/04/2021
CS359 Computer Networks Lab Assignment 11 
Filename: README.txt */

// This zip contains:

1) Assignment11_1801cs16_Report.pdf : contains all the results along with descriptions

2) All the wireshark traces used are in the zip.
	Wireshark Capture Filenames
	For Facebook Capture1: capture1_4pm.pcapng
	For Facebook Capture2: capture2_1pm.pcapng
	For Random Capture: random.pcapng
	For http request-response Capture: http_request_disney_capture.pcapng